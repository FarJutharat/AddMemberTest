import SwiftUI

struct AddMemberView: View {
    @FetchRequest(entity: UserData.entity(), sortDescriptors: []) var user : FetchedResults<UserData>
    @FetchRequest(entity: Contact.entity(), sortDescriptors: [
        NSSortDescriptor(keyPath: \Contact.name , ascending: true)
    ]) var contacts : FetchedResults<Contact>
    
    @Environment(\.presentationMode) var presentationModes
    @State var isSelect = 0
    @State var isNavigation = false
    @State var searchText : String = ""
    @State var selectionRow = Set<Contact>()
    @State var selectContactSearch : Contact? = nil
    @Binding var group_name : String
    @Binding var save : Bool
    @EnvironmentObject private var groupmodel : GroupModel
    @State private var load = false
    @State var controllerNaviRoot : Bool = false
    @State var isPresentGroupDetail = false
    @State var newGroup = [GroupData]()
    
    var body: some View {
        VStack {
            if load {
            VStack{
                if groupmodel.groups.isEmpty != true {
                    ForEach(groupmodel.groups, id: \.self.id){ index in
                    NavigationLink(
                        destination : GroupDetailView(groupId: index.group_id, group: index
                        ),
                       isActive : self.$isPresentGroupDetail,
                        label: {
                            EmptyView()
                        })
                }
                        //.isDetailLink(false) //Pop to root
                } //ForEach
            } //VStack
                
            SearchBarUI(text: $searchText)
                .padding([.leading,.trailing], 10)
                .padding([.bottom], 5)
                .padding(.top , 15)
            
            //Search
            if searchText.isEmpty != true {
                List( contacts.filter({ self.searchText.isEmpty ? true : $0.name!.contains(searchText) }), id: \.user_id) { index in
                        AddMemberCellView(contact: index, selectedItems: self.$selectionRow)
                    }.listStyle(PlainListStyle())
            } else {
            //Normal
            List(contacts , id: \.self, selection : $selectionRow){ indexs in
                AddMemberCellView(contact: indexs, selectedItems: self.$selectionRow)
                    }.listStyle(PlainListStyle())
            }
        } //if load
            else {
                Text("Load...")
            }
        } //VStack
        .onAppear{
            DispatchQueue.main.async {
                self.load = true
            }
        }
        .navigationBarTitle(Text("Add Members"), displayMode: .inline)
       // .navigationBarHidden(isNavigation)
        .navigationBarBackButtonHidden(true)
        .navigationBarItems(
            leading : Button(action: {
                presentationModes.wrappedValue.dismiss()
            },
                label: {
                Text("Cancel").foregroundColor(.black) }),
            trailing: Button(action: {
                if selectionRow.count != 0 {
                    let member_array = Array(selectionRow) //change set to array
                    print("member array \(member_array)")
                    self.groupmodel.addGroup(name: group_name, status: save, admin: user[0].name ?? "Unknow" , profile: "C", member: member_array)
                    //self.haveGroup = group_new
                    self.isPresentGroupDetail = true
                    self.isNavigation = true
                }
            },
                label: {
                    Text("Add (\(selectionRow.count))")
                        .foregroundColor( selectionRow.count == 0 ? .gray : .black)
                })
        ) //navigation bar item
    }
}

struct AddMemberView_Previews: PreviewProvider {
    static var previews: some View {
        NavigationView {
            AddMemberView(group_name: .constant("test"), save: .constant(true), controllerNaviRoot: true)
        }
    }
}

